import * as React from "react";
import RootNavigation from "./navigation";

export default function App() {
  return <RootNavigation />;
}
